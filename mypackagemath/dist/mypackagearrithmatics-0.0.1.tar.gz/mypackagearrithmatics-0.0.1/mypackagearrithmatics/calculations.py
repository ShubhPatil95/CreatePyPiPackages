def add(a,b):
  print("This is addition=>",a+b)
  
def sub(a,b):
  print("This is substraction=>",a-b)
